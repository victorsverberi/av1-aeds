#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    char continuar = 's';

    do {
        printf("Bem-vindo ao jogo Monty Hall!\n");

        srand(time(NULL));
        int portaPremiada = rand() % 3 + 1;//gera um numero aleatorio entre 1 e 3

        int portaEscolhida;
        printf("Escolha uma porta (1, 2 ou 3): ");
        scanf("%d", &portaEscolhida);

        int portaVazia = 0;//encontra a porta vazia
        for (int i = 1; i <= 3; i++) {
            if (i != portaEscolhida && i != portaPremiada) {
                portaVazia = i;
                break;
            }
        }
      //abre a porta vazia
        printf("O apresentador abriu a porta %d que esta vazia.\n", portaVazia);

        char trocarPorta;//jogador decide se deseja trocar de porta
        printf("Voce deseja trocar para a outra porta? (s/n): ");
        scanf(" %c", &trocarPorta);

        if (trocarPorta == 's') {//troca a porta escolhida
            for (int i = 1; i <= 3; i++) {
                if (i != portaEscolhida && i != portaVazia) {
                    portaEscolhida = i;
                    break;
                }
            }
        }
      //verifica se o jogador ganhou ou perdeu
        if (portaEscolhida == portaPremiada) {
            printf("Voce ganhou! Parabens!\n");
        } else {
            printf("Voce perdeu. A porta premiada era a %d.\n", portaPremiada);
        }
      //pergunta se o jogador deseja jogar de novo
        printf("Deseja jogar novamente? (s/n): ");
        scanf(" %c", &continuar);

    } while (continuar == 's');

    return 0;
}